// src/CurrentProject.js
import React from 'react';

function CurrentProject() {
  return (
    <div>
      <h2>Current Project</h2>
      <p>Details about the current project will be displayed here.</p>
    </div>
  );
}

export default CurrentProject;
    